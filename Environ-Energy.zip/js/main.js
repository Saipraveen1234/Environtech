(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    // Initiate the wowjs
    new WOW().init();

    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.sticky-top').addClass('shadow-sm').css('top', '0px');
        } else {
            $('.sticky-top').removeClass('shadow-sm').css('top', '-100px');
        }
    });
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });

    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });

    // Header carousel
    $(".header-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1500,
        loop: true,
        nav: false,
        dots: true,
        items: 1,
        dotsData: true,
    });

    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        center: true,
        dots: false,
        loop: true,
        nav : true,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsive: {
            0:{
                items:1
            },
            768:{
                items:2
            }
        }
    });

    // Portfolio isotope and filter
    var portfolioIsotope = $('.portfolio-container').isotope({
        itemSelector: '.portfolio-item',
        layoutMode: 'fitRows'
    });
    $('#portfolio-flters li').on('click', function () {
        $("#portfolio-flters li").removeClass('active');
        $(this).addClass('active');
        portfolioIsotope.isotope({filter: $(this).data('filter')});
    });

    // Mobile Navigation
    $('.mobile-menu-btn').click(function() {
        $(this).toggleClass('active');
        $('.nav-menu').toggleClass('active');
        $('body').toggleClass('menu-open');
    });

    // Close mobile menu when clicking on nav links
    $('.nav-link').click(function() {
        $('.mobile-menu-btn').removeClass('active');
        $('.nav-menu').removeClass('active');
        $('body').removeClass('menu-open');
    });

    // Close mobile menu when clicking outside
    $(document).click(function(e) {
        if (!$(e.target).closest('.header').length) {
            $('.mobile-menu-btn').removeClass('active');
            $('.nav-menu').removeClass('active');
            $('body').removeClass('menu-open');
        }
    });

    // Smooth scrolling for navigation links
    $('.nav-link[href^="#"]').on('click', function(e) {
        e.preventDefault();
        var target = $($(this).attr('href'));
        if (target.length) {
            $('html, body').animate({
                scrollTop: target.offset().top - 100
            }, 1000);
        }
    });

    // Header scroll behavior for mobile
    $(window).scroll(function () {
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
            $('.header').addClass('scrolled');
        } else {
            $('.header').removeClass('scrolled');
        }
    });

    // Solar Calculator Constants
    const UNITS_PER_KW = 1440;        // Annual units generated per kW
    const PRICE_PER_KW = 96589;       // Price per kW in ₹
    const SPACE_PER_KW = 80;          // Space required per kW in sqft
    const SAVINGS_PER_KW = 10080;     // Annual savings per kW in ₹
    const BASE_SUBSIDY = 30000;       // Base subsidy amount in ₹
    const SUBSIDY_PER_KW = 30000;     // Subsidy per kW in ₹ (30% of price per kW)
    const BILL_TO_KW_FACTOR = 700;    // Monthly bill amount that approximately equals 1 kW requirement
    const CO2_SAVED_PER_KW = 1200;    // CO2 saved per kW per year in kg
    const TREES_PER_KW = 15;          // Trees equivalent per kW
    

    // Calculator Functions
    function updateCalculatorResults(systemSize) {
        // Add loading state
        $('.result-card').addClass('loading');
        
        // Calculate results
        const spaceRequired = systemSize * SPACE_PER_KW;
        const annualEnergy = systemSize * UNITS_PER_KW;
        const annualSavings = systemSize * SAVINGS_PER_KW;
        const price = systemSize * PRICE_PER_KW;
        const subsidy = systemSize * SUBSIDY_PER_KW;
        
        // Simulate calculation delay for better UX
        setTimeout(() => {
            // Remove loading state and add updating animation
            $('.result-card').removeClass('loading');
            $('.result-card p').addClass('updating');
            
            // Update UI with formatted numbers
            $('#system-size').text(`${systemSize.toFixed(1)} kW`);
            $('#space-required').text(`${Math.round(spaceRequired)} sqft`);
            $('#energy-generated').text(`${Math.round(annualEnergy).toLocaleString()} Units`);
            $('#annual-savings').text(`₹ ${Math.round(annualSavings).toLocaleString()}`);
            $('#price-excluding-subsidy').text(`₹ ${Math.round(price).toLocaleString()}`);
            $('#subsidy').text(`₹ ${Math.round(subsidy).toLocaleString()}`);
            
            // Remove updating animation after it completes
            setTimeout(() => {
                $('.result-card p').removeClass('updating');
            }, 600);
        }, 500);
    }

    function calculateFromMonthlyBill(monthlyBill) {
        const estimatedSystemSize = monthlyBill / BILL_TO_KW_FACTOR;
        updateCalculatorResults(estimatedSystemSize);
    }

    function handleSystemSizeInput() {
        const systemSize = parseFloat($('#system-size-input').val()) || 0;
        updateCalculatorResults(Math.max(0, systemSize));
    }

    function handleMonthlyBillInput() {
        const monthlyBill = parseFloat($('#monthly-bill').val()) || 0;
        calculateFromMonthlyBill(Math.max(0, monthlyBill));
    }

    function initializeCalculator() {
        // Cache DOM elements
        const systemSizeSection = $('#system-size-section');
        const monthlyBillSection = $('#monthly-bill-section');
        const toggleLink = $('#toggle-calculation-method');
        const systemSizeInput = $('#system-size-input');
        const monthlyBillInput = $('#monthly-bill');

        // Set default state (Monthly bill mode)
        systemSizeSection.hide();
        monthlyBillSection.show();
        monthlyBillInput.val(2500);
        calculateFromMonthlyBill(2500);

        // Toggle between calculation methods
        let isMonthlyBillMode = true;
        
        toggleLink.on('click', function(e) {
            e.preventDefault();
            
            if (isMonthlyBillMode) {
                // Switch to System Size mode
                systemSizeSection.show();
                monthlyBillSection.hide();
                toggleLink.text('Or calculate savings using Monthly Bill');
                handleSystemSizeInput();
                isMonthlyBillMode = false;
            } else {
                // Switch to Monthly Bill mode
                systemSizeSection.hide();
                monthlyBillSection.show();
                toggleLink.text('Or calculate savings using System size(kW)');
                handleMonthlyBillInput();
                isMonthlyBillMode = true;
            }
        });

        systemSizeInput.on('input', handleSystemSizeInput);
        monthlyBillInput.on('input', handleMonthlyBillInput);

        // Button Handlers
        $('#start-journey').on('click', function() {
            const systemSize = parseFloat($('#system-size').text());
            alert(`Starting your solar journey with a ${systemSize}kW system!`);
        });

        $('#finance-info').on('click', function() {
            const totalCost = parseFloat($('#price-excluding-subsidy').text().replace(/[^\d.-]/g, ''));
            const subsidy = parseFloat($('#subsidy').text().replace(/[^\d.-]/g, ''));
            const netCost = totalCost - subsidy;
            alert(`Finance options available for ₹${netCost.toLocaleString()}!`);
        });
    }

    // Initialize Calculator when document is ready
    $(document).ready(function() {
        initializeCalculator();
        initializeSchemeNavigation();
        initializeCalculatorAnimations();
    });

    // Enhanced Calculator Animations
    function initializeCalculatorAnimations() {
        // Add hover effects for input groups
        $('.input-group').on('mouseenter', function() {
            $(this).find('::before').css('left', '100%');
        });

        // Add click animation for buttons
        $('.calculator-actions .btn').on('click', function(e) {
            const button = $(this);
            const ripple = $('<span class="ripple"></span>');
            
            button.append(ripple);
            ripple.css({
                left: e.offsetX + 'px',
                top: e.offsetY + 'px'
            });
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });

        // Add tooltip functionality
        $('.result-card[data-tooltip]').on('mouseenter', function() {
            const tooltip = $(this).attr('data-tooltip');
            const tooltipEl = $(`<div class="tooltip">${tooltip}</div>`);
            
            $('body').append(tooltipEl);
            
            const rect = this.getBoundingClientRect();
            tooltipEl.css({
                position: 'absolute',
                top: rect.top - 40 + 'px',
                left: rect.left + (rect.width / 2) - (tooltipEl.width() / 2) + 'px',
                zIndex: 1000
            });
        }).on('mouseleave', function() {
            $('.tooltip').remove();
        });
    }

    // Mobile Navigation
    $('.mobile-menu-btn').click(function() {
        $(this).toggleClass('active');
        $('.nav-menu').toggleClass('active');
        $('body').toggleClass('menu-open');
    });

    // Close mobile menu when clicking on nav links
    $('.nav-link').click(function() {
        $('.mobile-menu-btn').removeClass('active');
        $('.nav-menu').removeClass('active');
        $('body').removeClass('menu-open');
    });

    // Close mobile menu when clicking outside
    $(document).click(function(e) {
        if (!$(e.target).closest('.header').length) {
            $('.mobile-menu-btn').removeClass('active');
            $('.nav-menu').removeClass('active');
            $('body').removeClass('menu-open');
        }
    });

    // Smooth scrolling for navigation links
    $('.nav-link[href^="#"]').on('click', function(e) {
        e.preventDefault();
        var target = $($(this).attr('href'));
        if (target.length) {
            $('html, body').animate({
                scrollTop: target.offset().top - 100
            }, 1000);
        }
    });

    // Header scroll behavior for mobile
    $(window).scroll(function () {
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
            $('.header').addClass('scrolled');
        } else {
            $('.header').removeClass('scrolled');
        }
    });

    // Testimonials carousel mobile optimization

    // Solar Purpose Change Handler
    $('#solar-purpose').on('change', function() {
        const purpose = $(this).val();
        let hint = '';
        
        switch(purpose) {
            case 'Home':
                hint = 'Recommended size: 1-10 kW';
                break;
            case 'Business':
                hint = 'Recommended size: 10-100 kW';
                break;
            case 'Agriculture':
                hint = 'Recommended size: 5-50 kW';
                break;
        }
        
        // Update hint text if you have a hint element
        $('#size-hint').text(hint);
    });

    // Enhanced validation for number inputs
    $('input[type="number"]').on('input', function() {
        let value = parseFloat($(this).val());
        const min = parseFloat($(this).attr('min')) || 0;
        
        if (isNaN(value) || value < min) {
            $(this).val(min);
        }
    });

    // Scheme Navigation
    function initializeSchemeNavigation() {
        const navItems = document.querySelectorAll('.nav-item');
        const sections = document.querySelectorAll('.col-12[id], .col-md-6[id]');
        
        // Function to handle navigation
        function handleNavigation(targetId) {
            // Update active state
            navItems.forEach(item => {
                item.classList.remove('active');
                if (item.dataset.target === targetId) {
                    item.classList.add('active');
                }
            });
            
            // Scroll to section
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                window.scrollTo({
                    top: targetSection.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        }
        
        // Add click event listeners
        navItems.forEach(item => {
            item.addEventListener('click', () => {
                handleNavigation(item.dataset.target);
            });
        });
        
        // Add scroll event listener for highlighting current section
        window.addEventListener('scroll', () => {
            const scrollPosition = window.scrollY + 200;
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.offsetHeight;
                const sectionId = section.id;
                
                if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                    navItems.forEach(item => {
                        item.classList.remove('active');
                        if (item.dataset.target === sectionId) {
                            item.classList.add('active');
                        }
                    });
                }
            });
        });
    }

    // Header Functionality
    document.addEventListener('DOMContentLoaded', function() {
        const header = document.querySelector('.header');
        const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
        const navMenu = document.querySelector('.nav-menu');
        const navLinks = document.querySelectorAll('.nav-link');

        // Header scroll effect
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });

        // Mobile menu toggle
        mobileMenuBtn.addEventListener('click', function() {
            this.classList.toggle('active');
            navMenu.classList.toggle('active');
        });

        // Close mobile menu when clicking a link
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                mobileMenuBtn.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });

        // Active link highlighting
        function setActiveLink() {
            const sections = document.querySelectorAll('section[id]');
            const scrollY = window.pageYOffset;

            sections.forEach(section => {
                const sectionHeight = section.offsetHeight;
                const sectionTop = section.offsetTop - 100;
                const sectionId = section.getAttribute('id');
                
                if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                    document.querySelector('.nav-link[href*=' + sectionId + ']')?.classList.add('active');
                } else {
                    document.querySelector('.nav-link[href*=' + sectionId + ']')?.classList.remove('active');
                }
            });
        }

        window.addEventListener('scroll', setActiveLink);
    });

})(jQuery);

// Newsletter Form Functionality
function initializeNewsletterForm() {
    const newsletterForm = document.querySelector('.newsletter-form-container');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const emailInput = this.querySelector('input[type="email"]');
            const submitBtn = this.querySelector('button[type="submit"]');
            const email = emailInput.value.trim();
            
            if (email && isValidEmail(email)) {
                // Show loading state
                const originalBtnText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Subscribing...';
                submitBtn.disabled = true;
                
                // Simulate subscription process
                setTimeout(() => {
                    submitBtn.innerHTML = '<i class="fas fa-check me-2"></i>Subscribed!';
                    submitBtn.style.background = '#28a745';
                    emailInput.value = '';
                    
                    // Show success notification
                    showNotification('Successfully subscribed to our newsletter!', 'success');
                    
                    // Reset button after 3 seconds
                    setTimeout(() => {
                        submitBtn.innerHTML = originalBtnText;
                        submitBtn.style.background = '';
                        submitBtn.disabled = false;
                    }, 3000);
                }, 1500);
            } else {
                // Show error state
                emailInput.style.borderColor = '#dc3545';
                emailInput.style.boxShadow = '0 0 0 0.2rem rgba(220, 53, 69, 0.25)';
                emailInput.placeholder = 'Please enter a valid email address';
                
                showNotification('Please enter a valid email address', 'error');
                
                setTimeout(() => {
                    emailInput.style.borderColor = '';
                    emailInput.style.boxShadow = '';
                    emailInput.placeholder = 'Your Email Address';
                }, 3000);
            }
        });
    }
}

// Email validation helper function
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Initialize newsletter form when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeNewsletterForm();
});

// Scheme Modal Functionality
const schemeDetails = {
    'pm-suryoday': {
        title: 'PM Suryoday Yojana - Official Details',
        image: './img/schemes/pm-suryoday-scheme.jpg',
        filename: 'PM_Suryoday_Yojana_Details.jpg'
    },
    'rooftop-solar': {
        title: 'Rooftop Solar Subsidy Scheme',
        image: './img/schemes/rooftop-solar-scheme.jpg',
        filename: 'Rooftop_Solar_Scheme_Details.jpg'
    },
    'kusum-yojana': {
        title: 'PM-KUSUM Yojana Details',
        image: './img/schemes/kusum-yojana-scheme.jpg',
        filename: 'PM_KUSUM_Yojana_Details.jpg'
    },
    'solar-park': {
        title: 'Solar Park Scheme Details',
        image: './img/schemes/solar-park-scheme.jpg',
        filename: 'Solar_Park_Scheme_Details.jpg'
    }
};

function openSchemeModal(schemeId) {
    const scheme = schemeDetails[schemeId];
    if (!scheme) {
        console.error('Scheme not found:', schemeId);
        return;
    }
    
    const modal = document.getElementById('schemeModal');
    const modalTitle = document.getElementById('modalTitle');
    const schemeImage = document.getElementById('schemeImage');
    
    modalTitle.textContent = scheme.title;
    schemeImage.src = scheme.image;
    schemeImage.alt = scheme.title;
    
    // Store current scheme for download/share functions
    modal.setAttribute('data-current-scheme', schemeId);
    
    modal.classList.add('active');
    document.body.style.overflow = 'hidden'; // Prevent background scrolling
}

function closeSchemeModal() {
    const modal = document.getElementById('schemeModal');
    modal.classList.remove('active');
    document.body.style.overflow = 'auto'; // Restore scrolling
}

function downloadScheme() {
    const modal = document.getElementById('schemeModal');
    const schemeId = modal.getAttribute('data-current-scheme');
    const scheme = schemeDetails[schemeId];
    
    if (!scheme) return;
    
    // Create download link
    const link = document.createElement('a');
    link.href = scheme.image;
    link.download = scheme.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Show success message
    showNotification('Scheme details downloaded successfully!', 'success');
}

function shareScheme() {
    const modal = document.getElementById('schemeModal');
    const schemeId = modal.getAttribute('data-current-scheme');
    const scheme = schemeDetails[schemeId];
    
    if (!scheme) return;
    
    if (navigator.share) {
        // Use native sharing if available
        navigator.share({
            title: scheme.title,
            text: `Check out the ${scheme.title} details from our solar energy website!`,
            url: window.location.href
        }).then(() => {
            showNotification('Scheme details shared successfully!', 'success');
        }).catch(err => {
            console.log('Error sharing:', err);
            fallbackShare(scheme);
        });
    } else {
        // Fallback sharing options
        fallbackShare(scheme);
    }
}

function fallbackShare(scheme) {
    // Copy link to clipboard
    const shareUrl = `${window.location.href}#scheme-${scheme.title.toLowerCase().replace(/\s+/g, '-')}`;
    
    if (navigator.clipboard) {
        navigator.clipboard.writeText(shareUrl).then(() => {
            showNotification('Link copied to clipboard!', 'success');
        });
    } else {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = shareUrl;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        showNotification('Link copied to clipboard!', 'success');
    }
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span class="notification-icon">
            ${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}
        </span>
        <span class="notification-message">${message}</span>
    `;
    
    // Add styles if they don't exist
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: #fff;
                padding: 15px 20px;
                border-radius: 10px;
                box-shadow: 0 5px 20px rgba(0,0,0,0.2);
                z-index: 10001;
                display: flex;
                align-items: center;
                gap: 10px;
                animation: notificationSlideIn 0.3s ease;
                max-width: 300px;
            }
            .notification-success { border-left: 4px solid #4CAF50; }
            .notification-error { border-left: 4px solid #f44336; }
            .notification-info { border-left: 4px solid #2196F3; }
            .notification-icon {
                font-weight: bold;
                font-size: 1.2rem;
            }
            .notification-success .notification-icon { color: #4CAF50; }
            .notification-error .notification-icon { color: #f44336; }
            .notification-info .notification-icon { color: #2196F3; }
            @keyframes notificationSlideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'notificationSlideIn 0.3s ease reverse';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Close modal when clicking outside
document.addEventListener('click', function(event) {
    const modal = document.getElementById('schemeModal');
    if (modal && event.target === modal) {
        closeSchemeModal();
    }
});

// Close modal with Escape key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const modal = document.getElementById('schemeModal');
        if (modal && modal.classList.contains('active')) {
            closeSchemeModal();
        }
    }
});

// Modern Contact Form Functionality
function initializeContactForm() {
    const form = document.getElementById('quote-form');
    if (!form) return;
    
    const submitBtn = form.querySelector('.submit-btn-modern');
    const btnText = form.querySelector('.btn-text');
    
    // Form validation rules
    const validationRules = {
        name: {
            required: true,
            minLength: 2,
            pattern: /^[a-zA-Z\s]+$/,
            message: 'Please enter a valid name (letters and spaces only)'
        },
        email: {
            required: true,
            pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
            message: 'Please enter a valid email address'
        },
        mobile: {
            required: true,
            pattern: /^[0-9]{10}$/,
            message: 'Please enter a valid 10-digit mobile number'
        },
        service: {
            required: true,
            message: 'Please select a service type'
        }
    };
    
    // Real-time validation
    const inputs = form.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
        input.addEventListener('blur', () => validateField(input));
        input.addEventListener('focus', () => clearFieldValidation(input));
    });
    
    // Phone number formatting
    const mobileInput = form.querySelector('#mobile');
    if (mobileInput) {
        mobileInput.addEventListener('input', function() {
            let value = this.value.replace(/\D/g, '');
            if (value.length > 10) {
                value = value.substring(0, 10);
            }
            this.value = value;
        });
    }
    
    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (validateForm()) {
            submitForm();
        }
    });
    
    function validateField(field) {
        const fieldName = field.getAttribute('name');
        const fieldValue = field.value.trim();
        const rules = validationRules[fieldName];
        const formGroup = field.closest('.form-group');
        
        if (!rules) return true;
        
        // Check required
        if (rules.required && !fieldValue) {
            showFieldError(formGroup, 'This field is required');
            return false;
        }
        
        // Check minimum length
        if (rules.minLength && fieldValue.length < rules.minLength) {
            showFieldError(formGroup, `Minimum ${rules.minLength} characters required`);
            return false;
        }
        
        // Check pattern
        if (rules.pattern && fieldValue && !rules.pattern.test(fieldValue)) {
            showFieldError(formGroup, rules.message);
            return false;
        }
        
        // Field is valid
        showFieldSuccess(formGroup);
        return true;
    }
    
    function validateForm() {
        let isValid = true;
        
        inputs.forEach(input => {
            if (input.hasAttribute('required') && !validateField(input)) {
                isValid = false;
            }
        });
        
        return isValid;
    }
    
    function showFieldError(formGroup, message) {
        formGroup.classList.remove('success');
        formGroup.classList.add('error');
        
        // Remove existing error message
        const existingError = formGroup.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
        
        // Add error message
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.style.cssText = 'color: #dc3545; font-size: 12px; margin-top: 4px;';
        errorDiv.textContent = message;
        formGroup.appendChild(errorDiv);
    }
    
    function showFieldSuccess(formGroup) {
        formGroup.classList.remove('error');
        formGroup.classList.add('success');
        const errorMessage = formGroup.querySelector('.error-message');
        if (errorMessage) {
            errorMessage.remove();
        }
    }
    
    function clearFieldValidation(field) {
        const formGroup = field.closest('.form-group');
        formGroup.classList.remove('error', 'success');
        const errorMessage = formGroup.querySelector('.error-message');
        if (errorMessage) {
            errorMessage.remove();
        }
    }
    
    function submitForm() {
        // Add loading state
        submitBtn.classList.add('loading');
        btnText.textContent = 'Processing...';
        
        // Collect form data
        const formData = {
            name: form.querySelector('#name').value.trim(),
            email: form.querySelector('#email').value.trim(),
            mobile: form.querySelector('#mobile').value.trim(),
            service: form.querySelector('#service').value,
            message: form.querySelector('#message').value.trim()
        };
        
        // Simulate API call
        setTimeout(() => {
            // Remove loading state
            submitBtn.classList.remove('loading');
            btnText.textContent = 'Get Free Quote';
            
            // Show success message
            showSuccessMessage(formData);
            
            // Reset form
            resetForm();
            
        }, 2000);
    }
    
    function showSuccessMessage(formData) {
        const successHtml = `
            <div class="success-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 10000; display: flex; align-items: center; justify-content: center;">
                <div class="success-modal" style="background: white; padding: 40px; border-radius: 20px; text-align: center; max-width: 500px; margin: 20px; box-shadow: 0 20px 60px rgba(0,0,0,0.3);">
                    <div class="success-icon" style="font-size: 4rem; color: #28a745; margin-bottom: 20px;">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <h3 style="color: #333; margin-bottom: 15px;">Quote Request Submitted!</h3>
                    <p style="color: #666; margin-bottom: 10px;">Thank you <strong>${formData.name}</strong> for your interest in our solar solutions.</p>
                    <p style="color: #666; margin-bottom: 30px;">Our team will contact you at <strong>${formData.mobile}</strong> within 24 hours to discuss your ${formData.service.toLowerCase()} requirements.</p>
                    <button class="close-success-btn" style="background: var(--primary); color: white; border: none; padding: 12px 30px; border-radius: 25px; cursor: pointer; font-weight: 600;">Close</button>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', successHtml);
        
        // Close modal handlers
        const overlay = document.querySelector('.success-overlay');
        const closeBtn = document.querySelector('.close-success-btn');
        
        closeBtn.addEventListener('click', closeSuccessModal);
        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) {
                closeSuccessModal();
            }
        });
        
        function closeSuccessModal() {
            overlay.style.opacity = '0';
            overlay.style.transition = 'opacity 0.3s ease';
            setTimeout(() => {
                if (overlay.parentNode) {
                    overlay.remove();
                }
            }, 300);
        }
    }
    
    function resetForm() {
        form.reset();
        const formGroups = form.querySelectorAll('.form-group');
        formGroups.forEach(group => {
            group.classList.remove('error', 'success');
            const errorMessage = group.querySelector('.error-message');
            if (errorMessage) {
                errorMessage.remove();
            }
        });
    }
}

// Initialize contact form when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeContactForm();
});